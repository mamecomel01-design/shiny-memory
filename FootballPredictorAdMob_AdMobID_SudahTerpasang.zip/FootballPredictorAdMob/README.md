# Football Pro Analysis — AdMob Rewarded Interstitial

Project Android Studio untuk Football Predictor berbasis WebView.

## ID AdMob yang sudah dimasukkan

- Nama aplikasi: Football Pro Analysis
- App ID: `ca-app-pub-6222652873406581~6618307791`
- Ad Unit: Koin Gratis
- Rewarded Interstitial Ad Unit ID: `ca-app-pub-6222652873406581/7881086873`

## Implementasi

SDK Google Mobile Ads: `com.google.android.gms:play-services-ads:25.5.0`.

Tombol "Tonton Iklan +10" pada HTML memanggil Android bridge.
Android memuat `RewardedInterstitialAd`, lalu menampilkan layar pengantar yang:
- menjelaskan reward +10 koin;
- memberi pilihan "Tonton Iklan";
- memberi pilihan "Lewati".

Setelah callback `OnUserEarnedRewardListener` diterima, Android memanggil
`NativeRewardGranted(10)` pada HTML.

## Penting sebelum rilis

1. Gunakan test ad unit Google saat pengembangan. Jangan klik iklan produksi sendiri.
2. Pastikan aplikasi AdMob sudah terdaftar dan detail app/store sudah benar.
3. Siapkan UMP/consent jika aplikasi menayangkan iklan kepada pengguna di wilayah yang memerlukan consent.
4. Jangan memberi reward karena klik iklan; reward diberikan berdasarkan callback reward.
5. Untuk saldo koin yang tahan manipulasi, pindahkan sumber kebenaran saldo ke backend dan gunakan Server-Side Verification (SSV).
6. Jangan menampilkan iklan secara menyesatkan atau membuat pengguna merasa wajib mengklik iklan.

## Dokumentasi Google

Quick start:
https://developers.google.com/admob/android/quick-start?hl=id

Rewarded interstitial:
https://developers.google.com/admob/android/rewarded-interstitial?hl=id

Kebijakan AdMob:
https://support.google.com/admob/answer/6128543?hl=id
