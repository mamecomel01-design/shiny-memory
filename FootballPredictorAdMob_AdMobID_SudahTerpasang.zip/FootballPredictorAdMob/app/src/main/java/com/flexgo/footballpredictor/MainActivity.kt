package com.flexgo.footballpredictor

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var isLoadingAd = false

    // Football Pro Analysis - Koin Gratis
    private val rewardedInterstitialAdUnitId = "ca-app-pub-6222652873406581/7881086873"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AdBridge(), "Android")
        webView.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {
            runOnUiThread { loadRewardedInterstitialAd() }
        }
    }

    private fun loadRewardedInterstitialAd() {
        if (isLoadingAd || rewardedInterstitialAd != null) return
        isLoadingAd = true

        RewardedInterstitialAd.load(
            this,
            rewardedInterstitialAdUnitId,
            AdRequest.Builder().build(),
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    isLoadingAd = false
                    rewardedInterstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isLoadingAd = false
                    rewardedInterstitialAd = null
                }
            }
        )
    }

    private fun showRewardedInterstitialAd() {
        val ad = rewardedInterstitialAd
        if (ad == null) {
            notifyWebFailure("Iklan belum siap. Tunggu beberapa detik lalu coba lagi.")
            loadRewardedInterstitialAd()
            return
        }

        // Google requires a clear reward pre-prompt with an option to skip
        // before showing a rewarded interstitial.
        AlertDialog.Builder(this)
            .setTitle("🪙 Koin Gratis +10")
            .setMessage("Tonton iklan untuk mendapatkan 10 koin. Anda dapat melewati iklan ini.")
            .setPositiveButton("Tonton Iklan") { _, _ ->
                presentRewardedInterstitial(ad)
            }
            .setNegativeButton("Lewati") { _, _ ->
                notifyWebFailure("Iklan dilewati. Tidak ada koin yang ditambahkan.")
            }
            .setOnCancelListener {
                notifyWebFailure("Iklan dibatalkan. Tidak ada koin yang ditambahkan.")
            }
            .show()
    }

    private fun presentRewardedInterstitial(ad: RewardedInterstitialAd) {
        rewardedInterstitialAd = null

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                loadRewardedInterstitialAd()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                notifyWebFailure("Iklan gagal ditampilkan. Silakan coba lagi.")
                loadRewardedInterstitialAd()
            }

            override fun onAdShowedFullScreenContent() {
                // Ad is visible.
            }

            override fun onAdImpression() {
                // Impression recorded.
            }

            override fun onAdClicked() {
                // Ad clicked.
            }
        }

        ad.show(this, OnUserEarnedRewardListener { rewardItem ->
            // The ad unit is configured to grant 10 coins in the app.
            val rewardAmount = if (rewardItem.amount > 0) rewardItem.amount else 10
            webView.post {
                webView.evaluateJavascript(
                    "window.NativeRewardGranted && window.NativeRewardGranted($rewardAmount)",
                    null
                )
            }
        })
    }

    private fun notifyWebFailure(message: String) {
        webView.post {
            webView.evaluateJavascript(
                "window.NativeAdFailed && window.NativeAdFailed(${org.json.JSONObject.quote(message)})",
                null
            )
        }
    }

    inner class AdBridge {
        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread { showRewardedInterstitialAd() }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
